var a = new Date();
var timestamp = a.getTime();